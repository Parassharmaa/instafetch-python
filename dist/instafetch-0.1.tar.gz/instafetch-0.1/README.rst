Instapy
--------

To use (with caution), simply do::

    >>> from instafetch import Instafetch
    >>> i = Instafetch()
    >>> #search users
    >>> users = i.users(<keyword>)
