from instafetch.Instafetch import Instafetch
